<?php //echo $mainframe->getCfg('sitename') ;



?>&copy; 2007 - <?php echo date("Y"); ?> Phoca.cz | Designed by <a href="http://www.phoca.cz/" >Phoca</a>